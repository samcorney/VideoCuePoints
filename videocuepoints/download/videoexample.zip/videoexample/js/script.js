jQuery(window).load(function(){
	setupVideo();
});

var Subtitle = function(cuePoint, subtitleText){
	this.cuePoint = cuePoint;
	this.subtitleText = subtitleText;
};

function setupVideo(){
	var video = $('#example-video')[0];
	var subtitleHolder = $('#subtitle-text');
	var videoPauseRange = 0.5;
	var videoPauseCuePoints = [2.5];
	var textCuePoints = [new Subtitle(2.5, 'The video has hit a cue point and as such it has been paused!'), new Subtitle(5, 'You can also set the video to trigger events that effect elements outside of the video. This text has been triggered by the video passing the 5 second mark!')];
	var textFadedIn = false;
	var caughtVideo = false;

	$('#example-video').bind('timeupdate', function(){
		$.each(videoPauseCuePoints, function(index, value){
			if(video.currentTime > value && video.currentTime < value + videoPauseRange && !caughtVideo){
				caughtVideo = true;
				video.pause();
			}
		});
		$.each(textCuePoints, function(index, subtitle){
			if(video.currentTime > subtitle.cuePoint && video.currentTime < subtitle.cuePoint + videoPauseRange && !textFadedIn){
				subtitleHolder.html(subtitle.subtitleText);
				textFadedIn = true;
				waitAndReset();
			}
		});
	});

	$('#play-button').on('click', function(){
		if(video.paused){
			video.play();
			waitAndReset();
		}
	});

	function waitAndReset(){
		if(!video.paused){
			setTimeout(function(){
				caughtVideo = false;
				textFadedIn = false;
			}, videoPauseRange * 1000);
		}
	}
}